<h1 class="text-xxxl text-anim text-anim--slide js-text-anim">
  <span class="text-anim__wrapper js-text-anim__wrapper">
    <i class="text-anim__word text-anim__word--in js-text-anim__word">design</i>
    <i class="text-anim__word js-text-anim__word">develop</i>
    <i class="text-anim__word js-text-anim__word">create</i>
  </span>
</h1>;
