import "./App.css";
import "./Assets/css/style.css";
import "./Assets/css/animation.css";
import Home from "./Container/Home";
import BlankPage from "./Component/BlankPage";
// import {BrowserRouter as Router, Route} from 'react-router-dom';
import HeaderPage from "./Component/Header/HeaderPage";
import For_balancepdf from "./Component/for_balancepdf_page"
function App(props) {
  return (
    <div className="App">
       <Home />
    </div>
    
  );
}

export default App;
