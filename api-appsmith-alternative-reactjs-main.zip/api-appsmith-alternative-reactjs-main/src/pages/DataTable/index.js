import React, { useEffect, useState, useMemo, useContext } from "react";
import { TableHeader, Pagination, Search } from "../../components/Admin/DataTable";
import useFullPageLoader from "../../hooks/useFullPageLoader";
import { Link } from "react-router-dom";
import Button from '@material-ui/core/Button';
import contextFetchAppointment from '../../context/fetch_Appointments_data_total'
import  contextFetch from '../../context/fetch_Appointments_data_total'
import Appointments from '../../components/Admin/Appointments'
const DataTable = () => {
    const contextFetchdata = useContext(contextFetch);
    const [comments, setComments] = useState([]);
    const [loader, showLoader, hideLoader] = useFullPageLoader();
    const [totalItems, setTotalItems] = useState(0);
    const [currentPage, setCurrentPage] = useState(1);
    const [search, setSearch] = useState("");
    const [fetchFullData, setFetchFullData] = useState("");
    const [sorting, setSorting] = useState({ field: "", order: "" });

    const ITEMS_PER_PAGE = 50;
    const headers = [
        { name: "ID", field: "appointmentID", sortable: false },
        { name: "Name", field: "customer_name", sortable: true },
        { name: "phone", field: "customer_phone", sortable: true },
        { name: "status", field: "status", sortable: true },
        { name: "Email", field: "customer_email", sortable: true },
        { name: "Consult date", field: "consultDate", sortable: true },
        { name: "Consult time", field: "consultTime", sortable: true },
        { name: "Doctor Name", field: "dr_name", sortable: true },
        { name: "Therapy", field: "therapy_name", sortable: true },
        // { name: "Comment", field: "body", sortable: false }
    ];


    // useEffect(() => {
    //     console.log(" thsi is the pointer for context api data inside appointment component :", contextFetchdata )
    //     setComments(contextFetchdata.data);
    // }, []);
    useEffect(() => {
        const getData = () => {
            fetch("https://kapv-appsmith-module-doc.herokuapp.com/getappointmentsByDate/2022-09-08")
                .then(response => response.json())
                .then(json => {
                  setComments(json.data)
                    console.log("this is the fetch data",json);
                });
        };
  
        getData();
    }, []);
    const commentsData = useMemo(() => {
        let computedComments = comments;
        console.log(" this  is the page for search  computedComments:", computedComments)
        if (search) {
            console.log(search)
            computedComments = computedComments.filter(
                comment =>
                    comment.customer_name.toLowerCase().includes(search.toLowerCase()) ||
                    comment.customer_email.toLowerCase().includes(search.toLowerCase())
            );
        }

        setTotalItems(computedComments.length);

        //Sorting comments
        if (sorting.field) {
            const reversed = sorting.order === "asc" ? 1 : -1;
            computedComments = computedComments.sort(
                (a, b) =>
                    reversed * a[sorting.field].localeCompare(b[sorting.field])
            );
        }

        //Current Page slice
        return computedComments.slice(
            (currentPage - 1) * ITEMS_PER_PAGE,
            (currentPage - 1) * ITEMS_PER_PAGE + ITEMS_PER_PAGE
        );
    }, [comments, currentPage, search, sorting]);

    return (
        <>
            {/* <Header title="Building a data table in react" /> */}

            {/* <ExternalInfo page="datatable" /> */}
            <br/>

            <div className="row w-100">
                <div className="col mb-3 col-12 text-center">
                    <div className="row">
                        <div className="col-md-6">
                            <Pagination
                                total={totalItems}
                                itemsPerPage={ITEMS_PER_PAGE}
                                currentPage={currentPage}
                                onPageChange={page => setCurrentPage(page)}
                            />
                        </div>
                        <div className="col-md-6 d-flex flex-row-reverse">
                            <Search
                                onSearch={value => {
                                    {console.log(" pointer for search value", value)}
                                    setSearch(value);
                                    setCurrentPage(1);
                                }}
                            />
                        </div>
                    </div>
                               
                    <table className="table table-striped">
                        <TableHeader
                            headers={headers}
                            onSorting={(field, order) =>
                                setSorting({ field, order })
                            }
                        />
                        <tbody>
                            {commentsData.map(comment => (
                                <tr key={comment.customerID}>
                                    <th scope="row" key={comment.customerID}>
                                        {comment.appointmentID}
                                    </th>
                                    <td>{comment.customer_name}</td>
                                    <td>{comment.customer_phone}</td>
                                    <td>{comment.status}</td>
                                    <td>{comment.customer_email}</td>
                                    <td>{comment.consultDate}</td>
                                    <td>{comment.consultTime}</td>
                                    <td>{comment.dr_name}</td>
                                    <td>{comment.therapy_name}</td>
                                    <td>
                                    
                                      <Link to={`/MeetingData/`+comment.customerID+"/"+comment.customer_name}>
                                        <Button variant="contained" color="primary">  
                                           Consult
                                       </Button>
                                     </Link>
                                   
                                   
                                 </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
            {loader}
           
        </> 
    );
};

export default DataTable;
