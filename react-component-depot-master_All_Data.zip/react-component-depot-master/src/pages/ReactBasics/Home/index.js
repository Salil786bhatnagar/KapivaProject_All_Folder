import React from "react";

const ReactBasicsHome = () => {
    return <div>React Basics Home</div>;
};

export default ReactBasicsHome;
