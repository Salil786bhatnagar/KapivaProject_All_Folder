import logo from './logo.svg';
import './App.css';
import './Custom.css';
import {BrowserRouter as Router, Route} from 'react-router-dom';
import Dashboard from './Component/Admin/Dashboard';
import HeroBanner from './Component/Admin/HeroBanner';
import Index from './Component/DoctorsConsultation/Index';
import SearchFilter from './Component/DoctorsConsultation/SearchFilter';

function App(props) {
  return (
    <div className="App">
      <Router>
          <Route
          exact
          strict
          component={Dashboard}
          path="/"
          history={props.history}
          />

          <Route
          exact
          strict
          component={HeroBanner}
          path="/HeroBanner"
          history={props.history}
          />
          

          <Route
          exact
          strict
          component={Index}
          path="/Index"
          history={props.history}
          />

          <Route
          exact
          strict
          component={SearchFilter}
          path="/SearchFilter"
          history={props.history}
          />
          
          
      </Router>
    </div>
  );
}

export default App;
