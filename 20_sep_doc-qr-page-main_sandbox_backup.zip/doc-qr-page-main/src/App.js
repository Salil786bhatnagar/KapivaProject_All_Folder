import "./App.css";
import "./Assets/css/animation.css";
import "./Assets/css/style.css";
import Home from "./Container/Home";
function App(props) {
  return (
    <div className="App">
      <Home />
    </div>
  );
}

export default App;
