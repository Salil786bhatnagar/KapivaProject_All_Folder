import React from "react";
import DataForm from "../Component/DataForm";
import DataForm1 from "../Component/DataForm1";

export default function Home() {
  return (
    <div className="main">
      <DataForm1 />
    </div>
  );
}
