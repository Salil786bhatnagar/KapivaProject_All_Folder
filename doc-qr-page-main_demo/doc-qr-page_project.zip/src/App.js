import "./App.css";
import "./Assets/css/style.css";
import Home from "./Container/Home";

function App() {
  return (
    <div className="App">
      <Home />
    </div>
  );
}

export default App;
